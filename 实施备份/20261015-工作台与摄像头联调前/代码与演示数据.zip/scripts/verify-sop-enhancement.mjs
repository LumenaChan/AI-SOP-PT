import { createServer } from "vite";
import { createServer as createHttpServer } from "node:http";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import React from "react";
import { renderToString } from "react-dom/server";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(resolve(root, "package.json"));
const routerDomRoot = dirname(require.resolve("react-router-dom/package.json"));
const routerRequire = createRequire(resolve(routerDomRoot, "package.json"));
const routerRoot = dirname(routerRequire.resolve("react-router/package.json"));
const routerDomEntry = resolve(routerDomRoot, "dist/index.mjs");
const hmr = createHttpServer();
const server = await createServer({
  root,
  appType: "custom",
  logLevel: "error",
  resolve: {
    alias: [
      { find: "react-router-dom", replacement: routerDomEntry },
      {
        find: /^react-router$/,
        replacement: resolve(routerRoot, "dist/development/index.mjs"),
      },
      {
        find: "react-router/dom",
        replacement: resolve(routerRoot, "dist/development/dom-export.mjs"),
      },
    ],
  },
  server: {
    middlewareMode: true,
    hmr: { server: hmr },
    warmup: { clientFiles: [] },
  },
  optimizeDeps: { noDiscovery: true, include: [] },
  ssr: { noExternal: ["react-router-dom", "react-router"] },
});
try {
  const { MemoryRouter } = await server.ssrLoadModule(routerDomEntry);
  const { PrototypeDataProvider, normalizePrototypeData } =
    await server.ssrLoadModule("/src/prototypeData.jsx");
  const { RoutedApp } = await server.ssrLoadModule("/src/App.jsx");
  const raw = JSON.parse(
    readFileSync(resolve(root, "src/data/currentPrototypeData.json"), "utf8"),
  );
  const normalized = normalizePrototypeData(structuredClone(raw));
  for (const capabilityId of [
    "cap-demo-glove-20261015",
    "cap-demo-meter-20261015",
  ]) {
    const expected = raw.aiAnnotationCategories
      .filter((c) => c.capabilityId === capabilityId)
      .map((c) => c.id);
    assert.deepEqual(
      normalized.aiAnnotationCategories
        .filter((c) => c.capabilityId === capabilityId)
        .map((c) => c.id),
      expected,
      "已有同语义标注类别时不重复追加默认类别",
    );
  }
  const demoSession = normalized.arrangements.find(
    (a) => a.id === "practice-demo-20261015",
  ).sessions[0];
  const step = demoSession.steps[0];
  Object.assign(step, {
    score: 25,
    effectiveScore: 25,
    rawScore: 30,
    aiDecision: "uncertain",
    result: "画面遮挡",
  });
  demoSession.runtime.aiScoringApplications = [
    {
      id: "reload-score",
      stepId: step.id,
      status: "applied",
      appliedDeduction: 5,
    },
  ];
  const reloaded = normalizePrototypeData(
    structuredClone(normalized),
  ).arrangements.find((a) => a.id === "practice-demo-20261015").sessions[0];
  assert.equal(reloaded.steps[0].score, 25, "刷新未知会话仍保留有效扣分");
  assert.deepEqual(
    reloaded.evaluationSnapshot,
    demoSession.evaluationSnapshot,
    "刷新不改变锁定快照",
  );
  console.log("PASS 标注类别无重复追加、刷新保留有效扣分与锁定快照");

  const paths = [
    "/teacher/practices/practice-demo-20261015/stations/ws-demo-20261015",
    "/teacher/practices/practice-demo-20261015/students/student-demo-20261015",
    "/teacher/practices/practice-demo-20261015/results",
    "/admin/ai-capability-config/sop-demo-bench-20261015",
    "/admin/ai-capability-library/annotation?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/annotation?capabilityId=cap-demo-glove-20261015",
    "/admin/ai-capability-library/videos?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/training-data?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/training?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/publishing?capabilityId=cap-demo-meter-20261015",
    "/admin/workstations/ws-demo-20261015",
    "/teacher/sop/sop-demo-bench-20261015",
    "/teacher/sop/edit/sop-demo-large-20261015",
    {
      pathname: "/teacher/sop/edit/sop-demo-large-20261015",
      state: { stage: 1 },
    },
  ];
  for (const entry of paths) {
    const html = renderToString(
      React.createElement(
        PrototypeDataProvider,
        null,
        React.createElement(
          MemoryRouter,
          { initialEntries: [entry] },
          React.createElement(RoutedApp),
        ),
      ),
    );
    assert.ok(html.length > 100);
    assert.ok(!html.includes("页面暂未找到"));
    if (typeof entry === "object") assert.ok(html.includes("可见操作要求"));
    console.log(
      "PASS " +
        (typeof entry === "string" ? entry : entry.pathname + " [操作步骤]"),
    );
  }
  console.log("14 个页面/阶段渲染通过；此检查不执行浏览器视觉验收。");
} finally {
  await server.close();
  hmr.close();
}
