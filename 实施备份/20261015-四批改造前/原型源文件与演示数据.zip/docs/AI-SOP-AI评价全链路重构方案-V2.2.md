# AI-SOP AI评价全链路重构方案 V2.2

> 状态：**Architecture Frozen / 一期架构基线**
>
> 本文档已经完成两轮架构红队审查与场景穿行验证，并通过最终冻结 Checklist。
> 后续 AI 评价相关产品设计与原型修改，以本文档为最高优先级架构规范。
>
> 如本文档与旧版 AI 评价实现、旧 PRD、旧 AGENTS 约束或历史讨论存在冲突：
>
> **V2.2 优先。**
>
> 除非真实业务证明本文档定义的主链本身无法成立，否则后续发现的问题应作为实施细化、状态补充、技术方案或二期需求处理，不重新推翻总体架构。

---

## 一、文档定位

V2.2 是基于 V2.1 全链路场景穿行验证后的最终架构基线。

本版本重点修复以下 7 项闭环问题：

1. Completion Item 与 Score Rule 的评分覆盖问题；
2. 考试存在未决成绩时的发布阻断问题；
3. 系统暂停导致学生被错误判超时的问题；
4. SOP升级以后AI能力复用与Gate版本判断冲突；
5. 纠正动作与重复动作发生重复处罚；
6. Actor Track丢失与重新绑定缺少状态；
7. 最后一个Step缺少后续Step时无法正常关闭观察窗口。

除以上修正外，V2.1总体架构保持不变。

---

## 二、最终全链路

```text
教师业务标准
↓
SOP / Step
↓
Completion Condition
Score Rule
Safety Rule
Incomplete Policy
↓
Evaluation Mapping
↓
Evaluation Item
↓
Machine Event
↓
已有能力复用 / 配置 / 新训练
↓
Dataset / AI Package
↓
Workstation Profile
↓
Field Validation
↓
Compatibility Decision
↓
Evaluation Snapshot
↓
Student Session
↓
Actor Binding
↓
Observation
↓
Machine Event
↓
Evaluation Item Result
↓
Step Execution State
Completion Result
↓
Score Rule
↓
Teacher Review / Technical Handling
↓
Resolved Score
↓
Result Publish
↓
Difficult Sample Feedback
```

---

## 三、四个核心版本

正式版本体系只保留：

### 3.1 SOP Version

教师正式教学与评价标准。

### 3.2 Evaluation Mapping Version

教师业务规则对应的AI评价语义。

### 3.3 AI Package Version

模型、Tracking、Event Detection与运行参数集合。

### 3.4 Workstation Profile Version

摄像头、ROI、工位布局以及关键设备环境。

Evaluation Snapshot锁定：

```text
SOP Version
+
Mapping Version
+
AI Package Version
+
Workstation Profile Version
+
Validation / Compatibility Record
```

---

## 四、教师端SOP结构

一期继续只支持：

> **线性必做型SOP。**

暂时不支持：

- 分支；
- 可选步骤。

每个Step包含：

```text
Step ID
步骤名称
前置步骤
标准操作说明
操作要点
完成条件
建议完成时间
步骤满分
期望评价方式
Incomplete Policy
Score Rules
Safety Rules
Flow Policy
```

---

## 五、Completion Condition

Completion Condition回答：

> 这个Step如果完整完成，应当满足什么条件。

例如：

> 完成工具自检、A点验电、B点验电。

它用于判断：

> Completion Result。

但不能直接决定：

> 最终分数。

---

## 六、Incomplete Policy

正式保留三种：

### 6.1 Zero Score

步骤没有完整完成：

> 本步骤0分。

### 6.2 Rule Based

步骤没有完整完成：

> 按Score Rule计算剩余分值。

### 6.3 Teacher Review

步骤没有完整完成：

> 由教师确定成绩。

---

## 七、Completion Scoring Coverage

如果：

> Incomplete Policy = Rule Based

那么所有影响Completion的业务要求必须存在明确的评分处置。

例如：

```text
Completion Item：
E03-01 工具自检
E03-02 A点验电
E03-03 B点验电
```

必须能够追溯：

```text
E03-01 → SR03-01
E03-02 → SR03-02
E03-03 → SR03-03
```

或者明确：

> 当前要求未满足不扣分，仅影响完成度。

但不能：

> 没有任何Score Treatment。

### 为什么在Mapping阶段检查

教师发布SOP时还没有Evaluation Item。

正确流程：

```text
教师发布SOP
↓
AI实施拆Evaluation Item
↓
系统做Completion Scoring Coverage检查
```

如果Coverage失败：

> Mapping不能进入待教师确认。

AI实施人员：

> 无权自行决定扣分。

必须退回教师，由教师创建新SOP版本补充规则或调整Incomplete Policy。

---

## 八、Score Rule

Score Rule定义：

- 错误名称；
- 类型；
- 扣分方式；
- 扣分值；
- 最大触发次数；
- 纠正后处理。

AI实施人员只能：

> 将Score Rule映射到Evaluation Item。

不能修改：

> 教师定义的扣分值。

---

## 九、Safety Rule

Safety Rule承担：

> 安全业务标准。

AI运行时产生的只是：

> Safety Candidate。

是否真正成立：

> 默认由教师确认。

---

## 十、Evaluation Item

Evaluation Item建议保存：

```text
name
type
roles
sourceCompletion
sourceScoreRuleIds
sourceSafetyRuleIds
machineEventIds
```

roles支持：

- completion；
- scoring；
- safety。

---

## 十一、Machine Event

Machine Event表示：

> Runtime能够确认的机器事实。

例如：

```text
验电笔出现
验电笔进入A区
A区有效停留成立
拆卸动作发生
```

Machine Event不能直接扣分，必须：

```text
Machine Event
↓
Evaluation Item
↓
Score Rule
```

---

## 十二、能力建设：复用优先

每个Machine Event先判断：

### Existing Capability

已有能力满足要求：

> 直接复用。

### Configuration Only

例如ROI、时序：

> 只配置，不训练。

### Training Required

确实缺能力：

> 才进入数据准备 → Dataset → Training。

---

## 十三、数据链

```text
Source Video
↓
Time Range Annotation
↓
Frame / Action Annotation
↓
Review
↓
Dataset
↓
Train / Validation / Test
↓
AI Package
```

### Source Video

只代表原始视频，不直接进入Dataset。

### Time Range Annotation

产品可以显示为“动作片段”，底层只需保存：

```text
sourceVideoId
startTime
endTime
label
```

不强制生成新的物理mp4。

### 数据类型

Detect：

> frame + bbox

Action Recognition：

> time range + action label

ROI / Sequence：

> 不要求训练新模型。

### Train / Validation / Test

至少按Source Video分组隔离，避免同一原视频相邻帧同时进入Train和Test造成数据泄漏。

### 正式运行数据回流

不能直接进入Dataset。

必须：

```text
Difficult Sample Candidate
↓
Data Processing
↓
Annotation
↓
Review
↓
Dataset
```

---

## 十四、AI Package

AI Package内部可包含：

```text
Detection Model
Pose Model
Action Model
Tracking Config
Event Detection Parameters
Confidence Thresholds
Duration Thresholds
Debounce
Cooldown
```

以下关键变化：

> AI Package升版。

例如：

- 换模型；
- 改关键阈值；
- 改Duration；
- 改Tracking逻辑。

单纯技术参数变化：

> 不修改Mapping。

---

## 十五、Workstation Profile

Workstation Profile包含：

- Camera配置；
- ROI坐标；
- 机位；
- 光照；
- 遮挡条件；
- 关键工具/设备环境摘要。

不同工位可以：

> 使用相同ROI Requirement，但拥有不同实际坐标。

---

## 十六、多摄像头一期策略

一期不做复杂：

> Cross-camera Event Fusion。

每个关键评价项指定：

### Primary Evidence Source

主要摄像头。

### Fallback Evidence Source

备用摄像头。

Primary不可用时：

> 才尝试Fallback。

避免两路摄像头把同一个动作计成两次。

---

## 十七、Field Validation

继续使用8大场景作为测试场景分类：

1. 标准流程；
2. 漏步；
3. 错序；
4. 错工具；
5. 错误后纠正；
6. AI不确定 / 遮挡；
7. 摄像头掉线；
8. 安全红线。

但不做：

> Evaluation Item × 8场景的机械笛卡尔积。

改为：

> Validation Test Case。

一个Case可以覆盖多个Evaluation Items。

系统最终计算：

> Evaluation Item Coverage。

---

## 十八、Actor Binding

Session开始：

```text
Student
↓
Assigned Workstation
↓
Person Detection
↓
Teacher/System Confirmation
↓
Primary Actor
```

### Actor Binding状态

```text
confirmed
uncertain
lost
rebind_required
```

### confirmed

只有Primary Actor产生的学生操作事件：

> 可以用于自动评分。

### uncertain

短暂遮挡、多人交叉、Tracking不稳定。

此时：

> 暂停产生新的负向自动评价。

### lost

Primary Actor持续丢失。

系统产生：

> Technical Incident。

### rebind_required

系统无法自动确认新的Track属于原学生。

教师需要：

> 重新确认学生。

重新绑定时保存Binding History。

之前已确认的有效证据：

> 不失效。

---

## 十九、多人进入关键操作区

第二Actor出现时，不立即全局停止。

只有第二Actor：

- 持续进入关键操作ROI；
- 或与关键工具发生空间交互；

才产生：

> Assistance Warning。

相关评价项：

> 暂停自动确认。

非Primary Actor的操作：

> 不进入学生成绩。

---

## 二十、Correction Context

当学生已经触发某个错误以后进入纠正流程：

```text
Violation
↓
Correction Context Open
```

随后用于纠正的动作：

> 不再自动作为普通重复动作处罚。

例如正确顺序：

> A → B

学生：

```text
B
A
B
```

第一次B：

> Sequence Violation。

后面的A→B：

> 属于Correction Attempt。

最后一个B：

> 不再额外触发Repeat。

Correction Context内部状态建议：

```text
active
relatedRuleId
relatedStepId
startedAt
completedAt
```

关闭条件：

- 纠正完成；
- 教师关闭；
- Step关闭；
- Session结束；
- Safety Block；
- 纠正超时。

---

## 二十一、Step运行状态拆成两层

### Execution State

表示流程状态：

```text
waiting
active
paused
closed
safety_blocked
terminated
```

### Completion Result

表示完成程度：

```text
complete
partial
not_completed
uncertain
not_evaluable
```

三者应与Score独立。

例如：

```text
Execution = closed
Completion = partial
Score = 15/20
```

---

## 二十二、Step Observation Window

每个Step都有有效观察窗口。

Window开启以后：

> 该Step相关Machine Events才进入判断。

### 开启条件

通常：

- 前置Step关闭；
- 当前Step入口事件；
- 教师手工开始。

### 关闭条件

正式支持：

#### Next Step Entry

后续Step开始。

#### Session Finish

学生本次操作结束。

#### Terminal Event

例如设备复位完成。

#### Teacher Close

教师明确关闭当前Step。

#### Timeout + Flow Decision

业务允许超时后关闭时使用。

### 最后一个Step

因为不存在Next Step，所以：

```text
Session Finish
↓
最后一个Step Observation Window Close
↓
检查Completion Items
↓
形成Completion Result
```

---

## 二十三、漏步判定

只有在以下条件同时满足时，才能形成负向缺失判断：

- Observation Window有效；
- Actor有效；
- Camera / AI证据链有效；
- 当前Completion没有满足；
- Observation Window已经关闭。

禁止：

> 一时没有检测到 → 漏步。

---

## 二十四、Evaluation Clock

所有超时评分：

> 不能直接使用Wall Clock。

### Wall Clock

真实经过时间。

### Evaluation Clock

真正允许计入学生操作时长的时间。

概念公式：

```text
Evaluation Duration
=
Wall Duration
-
System Paused Duration
-
Approved Teacher Pause
```

### 必须暂停Evaluation Clock的情况

- Safety Candidate导致系统暂停；
- Actor丢失且要求重新绑定；
- 系统技术异常导致学生无法继续；
- 教师正式暂停Session。

### 不一定暂停的情况

例如辅助摄像头掉线，但学生仍然可以继续正常操作：

> Evaluation Clock继续。

Technical Incident本身：

> 不自动暂停计时。

只有Step/Session进入Paused：

> 才暂停Evaluation Clock。

超时规则必须基于：

> Evaluation Clock。

---

## 二十五、Technical Incident

统一管理：

```text
camera_offline
frame_loss
severe_occlusion
tracking_lost
model_timeout
inference_unavailable
```

技术异常：

> 不能自动形成学生负向结论。

---

## 二十六、练习技术异常

练习继续：

> Default Pass。

即：

> AI技术失败不造成负向扣分。

---

## 二十七、考试技术异常

考试：

```text
Technical Incident
↓
Evaluation Item = Unobservable / Uncertain
↓
Score Disposition = Pending
```

系统：

> 不自动扣分。

同时：

> 不自动送满分。

---

## 二十八、Score Disposition

正式状态：

```text
pending
teacher_resolved
retest_required
retest_resolved
policy_protected
normal
```

### teacher_resolved

教师根据现场观察、视频或其他有效证据给出最终结论。

### retest_required

需要补测，当前成绩不能发布。

### retest_resolved

补测完成，使用补测结果形成最终成绩。

### policy_protected

学校政策明确规定采用保护性成绩处理。

这属于：

> 学校制度。

不是AI系统默认规则。

---

## 二十九、考试发布Gate

考试发布前必须检查：

```text
所有学生
所有Step
所有Score Disposition
```

以下任一存在：

> 阻止发布。

包括：

- Pending Teacher Review；
- Pending Score Disposition；
- Safety Candidate未处理；
- Retest Required未完成；
- Step Score仍为空；
- Session结果未冻结。

发布失败提示例如：

> 当前还有3名学生存在未完成的技术异常成绩处置，无法发布考试成绩。

发布后：

> 成绩不可直接修改。

如需调整：

> 形成成绩修订 / Score Version记录。

---

## 三十、Safety Candidate

AI疑似检测到安全红线：

```text
Safety Candidate
↓
Session Paused
↓
Evaluation Clock Paused
```

系统立即：

- 暂停自动评价；
- 通知教师；
- 保存证据。

教师：

### False Positive

恢复Session与Evaluation Clock。

学生：

> 不承担AI误报导致的时间损失。

### Confirmed Safety Violation

读取教师Safety Rule决定：

- 是否0分；
- 是否终止；
- 是否继续；
- 是否等待教师判定。

安全暂停：

> 不等于自动成绩处罚。

---

## 三十一、Scoring Engine

输入：

```text
Score Rules
Completion Result
Evaluation Item Results
Teacher Reviews
Score Dispositions
```

输出：

```text
baseScore
deductions
manualAdjustments
effectiveScore
scoreStatus
```

AI Confidence：

> 永远不能直接变成学生得分。

---

## 三十二、AI Impact Assessment

每次新SOP版本发布后：

> 执行AI影响分析。

### 非AI影响变化

例如：

- 文案修正；
- 教学说明修改；
- 示教图片变化。

结论：

> 原Mapping / AI Package / Validation可继续兼容。

### 评分变化

例如：

> A点遗漏5分 → 8分。

可能得到：

```text
Mapping:
需更新Score关联

AI Package:
Compatible

Workstation Visual Validation:
Compatible

Scoring Regression:
Required
```

### 新动作 / 新工具

例如新增绝缘钳识别：

```text
Mapping:
Update Required

AI Capability:
Missing

Data Requirement:
Required

AI Package:
New Version Required

Field Validation:
Required
```

---

## 三十三、Compatibility Decision

Gate不能只要求：

> 所有版本号完全相等。

AI Impact Assessment应输出兼容结论，例如：

```text
From SOP V1.2
To SOP V1.3

Mapping M3:
Compatible

AI Package P5:
Compatible

Workstation Profile WP3:
Compatible

Validation VAL-021:
Compatible
```

生产Gate检查：

```text
Current SOP
Current Mapping
Current AI Package
Current Workstation Profile
Validation
Compatibility Decision
```

只要存在明确有效的兼容记录：

> 不要求版本字符串完全相等。

Compatibility至少保存：

```text
fromVersion
toVersion
decision
affectedLayers
reason
operator
time
```

---

## 三十四、评价结果展示

不显示缺乏稳定数学定义的：

> “92分中76%来自AI”。

改为：

> 评价覆盖情况。

例如：

```text
自动AI完成：12项
教师复核：2项
人工评价：3项
技术不可评价并已处置：1项
```

或者按Step：

```text
6个Step
4个AI完整评价
1个人机混合评价
1个存在技术异常
```

---

## 三十五、Runtime Simulator

为了产品原型验证，建议增加：

> Runtime Simulator。

它不是正式生产模块，但必须能够Mock验证全链路状态。

### 支持正常事件

- 自检完成；
- A点完成；
- B点完成。

### 支持错误

- B先于A；
- 错工具；
- 漏A点。

### 支持纠正

- 开始纠正；
- 完成纠正。

### 支持Actor

- 第二人进入；
- Actor丢失；
- 重新绑定。

### 支持技术异常

- Camera Offline；
- Camera Restore。

### 支持安全

- Safety Candidate；
- 教师确认；
- 教师否决。

实时展示：

```text
Actor
↓
Machine Event
↓
Evaluation Item
↓
Execution State
↓
Completion Result
↓
Score Rule
↓
Score
```

同时显示：

> Evaluation Clock。

---

## 三十六、核心数据对象

```text
SOP
├ Step
├ ScoreRule
└ SafetyRule

EvaluationMapping
├ EvaluationItem
└ MachineEvent

VisualClass
ActionClass
RoiRequirement

SourceVideo
TimeRangeAnnotation
TrainingFrame
Annotation
Dataset

AiPackage

WorkstationProfile

ValidationRecord
ValidationTestCase

AiImpactAssessment

EvaluationSnapshot

Session
├ ActorBinding
├ MachineEventOccurrence
├ EvaluationItemResult
├ StepResult
├ CorrectionContext
├ ScoreDecision
├ TechnicalIncident
└ TeacherReview

DifficultSampleCandidate
```

---

## 三十七、StepResult建议字段

```text
stepId

executionState
completionResult

evaluationClock
wallClock

score
scoreStatus
scoreDisposition

triggeredRuleIds
technicalIncidentIds

startedAt
closedAt
```

---

## 三十八、ActorBinding建议字段

```text
sessionId
studentId

currentTrackId
status

history[]

confirmedBy
confirmedAt
```

---

## 三十九、ScoreDecision建议字段

```text
stepId

baseScore
deductions[]
manualAdjustment

effectiveScore

disposition
resolvedBy
resolvedAt
```

---

## 四十、AiImpactAssessment建议字段

```text
id

fromSopVersion
toSopVersion

mappingImpact
aiPackageImpact
workstationImpact
validationImpact
scoringImpact

compatibilityDecision

reason
operator
createdAt
```

---

## 四十一、最终业务不变量

以下规则必须永久成立。

### 不变量1

AI实施人员不能改变教师分值。

### 不变量2

Machine Event不能直接扣分。

### 不变量3

AI没看到不能直接判学生没做。

### 不变量4

技术异常不能自动产生学生负向结论。

### 不变量5

系统自己造成的暂停不能变成学生超时。

### 不变量6

非Primary Actor的操作不能进入学生成绩。

### 不变量7

纠正动作不能被重复处罚。

### 不变量8

存在Pending成绩时不能发布考试。

### 不变量9

版本复用必须经过明确Compatibility判断。

### 不变量10

任何最终分数必须能够追溯到：

> 教师规则 + 评价事实 + 人工处置记录。

---

## 四十二、一期原型必须真实表达的交互

### 教师端

- 创建Score Rule；
- 设置Incomplete Policy；
- 设置纠正规则；
- 创建Safety Rule；
- 发布SOP。

### AI实施端

- 创建Evaluation Item；
- 设置roles；
- 创建Machine Event；
- 判断已有能力复用 / 配置 / 训练；
- 教师确认Mapping；
- Completion Scoring Coverage校验。

### 数据端

- 上传Source Video；
- 设置Time Range；
- 关联Action / Evaluation Item；
- 模拟抽帧；
- 简化标注；
- 审核；
- 加入Dataset。

### AI Package

- 创建候选能力包；
- 展示复用能力；
- 展示新训练能力；
- 模拟验证；
- 部署。

### Workstation

- 配置ROI；
- 选择Primary / Fallback Camera；
- 创建Validation Test Case；
- 查看Coverage。

### Runtime

必须能Mock：

- Actor确认；
- 正常事件；
- 漏步；
- 错序；
- 纠正；
- 多人进入；
- 摄像头掉线；
- 安全红线；
- 教师复核；
- Evaluation Clock暂停与恢复；
- Score Disposition处理；
- 考试发布Gate。

Mock必须真正改变共享状态，不能只有Toast。

---

## 四十三、一期原型明确不要求真实实现

不要求：

- 真FFmpeg切片；
- 真YOLO训练；
- 真GPU队列；
- 真Action Recognition训练；
- CVAT级标注平台；
- 真Tracking算法；
- 真状态机推理服务；
- 真RTSP多路实时推理。

允许：

> Mock。

但产品数据关系、状态流转和页面表现必须符合本文档。

---

## 四十四、Codex实施必须分四批

### 第一批：教师标准 + Evaluation Mapping

包括：

- Score Rule；
- Incomplete Policy；
- Completion Scoring Coverage；
- Safety Rule；
- 移除分支/可选Step；
- Evaluation Mapping；
- Evaluation Item；
- roles；
- Machine Event；
- 能力复用判断；
- 教师业务口径确认。

验收主链：

```text
教师业务规则
↓
Evaluation Item
↓
Machine Event
```

### 第二批：数据 + AI Package

包括：

- Source Video；
- Time Range Annotation；
- 数据加工；
- Annotation；
- Dataset；
- Train / Validation / Test；
- AI Package。

验收主链：

```text
Machine Event
↓
已有能力 / Data Requirement
↓
Dataset
↓
AI Package
```

### 第三批：Runtime + Scoring

包括：

- Actor Binding；
- Actor Binding状态机；
- Correction Context；
- Observation Window；
- Evaluation Clock；
- Runtime Simulator；
- Evaluation Item Result；
- Step Execution State；
- Completion Result；
- Technical Incident；
- Score Disposition；
- Safety Candidate；
- Teacher Review；
- Exam Publish Gate。

验收主链：

```text
Actor
↓
Machine Event
↓
Evaluation Item Result
↓
Step
↓
Score
```

### 第四批：Workstation + Validation + Compatibility

包括：

- Workstation Profile；
- Primary / Fallback Camera；
- Validation Test Case；
- Coverage；
- Evaluation Snapshot；
- AI Impact Assessment；
- Compatibility Gate；
- Difficult Sample Feedback。

---

## 四十五、每批Codex开始修改前必须先Review

Codex必须先输出：

1. 当前相关数据结构；
2. 当前相关页面；
3. 当前旧逻辑与V2.2冲突点；
4. 本批新增/修改对象；
5. 可以复用的旧逻辑；
6. 数据迁移方案；
7. 本批明确不修改的范围；
8. 测试方案。

完成Review后：

> 再开始代码修改。

不得未经分析直接大规模重写。

---

## 四十六、每批必须执行的验证

至少：

- build；
- business tests；
- 1280px浏览器检查；
- 827px浏览器检查；
- Mock状态真实流转；
- 刷新后数据一致；
- 角色权限正确；
- 版本快照正确；
- 不出现假Toast成功；
- 不破坏与本批无关的既有页面。

---

## 四十七、架构冻结结论

V2.2已经完成：

- 第一轮架构红队；
- 第二轮架构红队；
- 全链路场景穿行；
- 最终冻结Checklist。

最终：

> **没有新的P0级架构问题。**

因此正式冻结为：

# AI-SOP V2.2 — Architecture Frozen

后续发现：

### 页面缺字段

直接修，不重新开架构。

### 状态遗漏

补状态，不重新开架构。

### Mock逻辑错误

修代码，不重新开架构。

### 某AI模型实现不了

调整AI Package技术路线，不修改教师业务架构。

### 只有真实业务证明主链本身无法成立

才重新开启架构评审。

---

## 四十八、Codex优先级规则

后续Codex执行时，优先级按照：

```text
本文件 V2.2
>
本轮明确的用户指令
>
现有代码中不冲突的业务逻辑
>
旧版PRD / 旧AI评价文档 / 历史实现
```

但是以下既有原则继续有效：

- 技术问题不自动扣学生分；
- AI不确定不能直接判学生错误；
- 发布SOP不依赖AI已经准备完成；
- AI安全监测不是唯一物理安全保障；
- 教师业务标准不能被AI实施人员修改；
- 所有正式结果必须可审计。
