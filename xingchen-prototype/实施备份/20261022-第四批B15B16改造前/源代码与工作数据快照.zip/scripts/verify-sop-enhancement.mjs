import { createServer } from "vite";
import { createServer as createHttpServer } from "node:http";
import { createRequire } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import React from "react";
import { renderToString } from "react-dom/server";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(resolve(root, "package.json"));
const routerDomRoot = dirname(require.resolve("react-router-dom/package.json"));
const routerRequire = createRequire(resolve(routerDomRoot, "package.json"));
const routerRoot = dirname(routerRequire.resolve("react-router/package.json"));
const routerDomEntry = resolve(routerDomRoot, "dist/index.mjs");
// SSR must not replace the running preview server's optimized dependency cache.
const cacheDir = mkdtempSync(resolve(tmpdir(), "sop-page-verification-"));
const hmr = createHttpServer();
const server = await createServer({
  root,
  cacheDir,
  appType: "custom",
  logLevel: "error",
  resolve: {
    alias: [
      { find: "react-router-dom", replacement: routerDomEntry },
      {
        find: /^react-router$/,
        replacement: resolve(routerRoot, "dist/development/index.mjs"),
      },
      {
        find: "react-router/dom",
        replacement: resolve(routerRoot, "dist/development/dom-export.mjs"),
      },
    ],
  },
  server: {
    middlewareMode: true,
    hmr: { server: hmr },
    warmup: { clientFiles: [] },
  },
  optimizeDeps: { noDiscovery: true, include: [] },
  ssr: { noExternal: ["react-router-dom", "react-router"] },
});
try {
  const { MemoryRouter } = await server.ssrLoadModule(routerDomEntry);
  const { PrototypeDataProvider, normalizePrototypeData } =
    await server.ssrLoadModule("/src/prototypeData.jsx");
  const { RoutedApp } = await server.ssrLoadModule("/src/App.jsx");
  const raw = JSON.parse(
    readFileSync(resolve(root, "src/data/currentPrototypeData.json"), "utf8"),
  );
  const normalized = normalizePrototypeData(structuredClone(raw));
  for (const capabilityId of [
    "cap-demo-glove-20261015",
    "cap-demo-meter-20261015",
  ]) {
    const expected = raw.aiAnnotationCategories
      .filter((c) => c.capabilityId === capabilityId)
      .map((c) => c.id);
    assert.deepEqual(
      normalized.aiAnnotationCategories
        .filter((c) => c.capabilityId === capabilityId)
        .map((c) => c.id),
      expected,
      "已有同语义标注类别时不重复追加默认类别",
    );
  }
  const demoSession = normalized.arrangements.find(
    (a) => a.id === "practice-demo-20261015",
  ).sessions[0];
  const step = demoSession.steps[0];
  Object.assign(step, {
    score: 25,
    effectiveScore: 25,
    rawScore: 30,
    aiDecision: "uncertain",
    result: "画面遮挡",
  });
  demoSession.runtime.aiScoringApplications = [
    {
      id: "reload-score",
      stepId: step.id,
      status: "applied",
      appliedDeduction: 5,
    },
  ];
  const reloaded = normalizePrototypeData(
    structuredClone(normalized),
  ).arrangements.find((a) => a.id === "practice-demo-20261015").sessions[0];
  assert.equal(reloaded.steps[0].score, 25, "刷新未知会话仍保留有效扣分");
  assert.deepEqual(
    reloaded.evaluationSnapshot,
    demoSession.evaluationSnapshot,
    "刷新不改变锁定快照",
  );
  console.log("PASS 标注类别无重复追加、刷新保留有效扣分与锁定快照");
  const revisedDemo = normalized.arrangements.find(
    (a) => a.id === "practice-grade-evidence-completed-20261022",
  ).sessions[0];
  assert.equal(revisedDemo.score, 98, "统一修订分加载后不被默认通过覆盖");
  assert.equal(revisedDemo.scoreVersion, 3);
  const reloadRevision = normalizePrototypeData(
    structuredClone(normalized),
  ).arrangements.find(
    (a) => a.id === "practice-grade-evidence-completed-20261022",
  ).sessions[0];
  assert.equal(reloadRevision.score, 98);
  assert.equal(reloadRevision.scoreVersion, 3);
  assert.deepEqual(
    reloadRevision.originalScoreRecord,
    revisedDemo.originalScoreRecord,
  );
  const frozenInput = structuredClone(normalized),
    frozenSession = frozenInput.arrangements.find(
      (a) => a.id === "exam-grade-evidence-frozen-20261022",
    ).sessions[0];
  frozenSession.score = 81;
  frozenSession.steps[0].effectiveScore = 11;
  frozenSession.steps[0].score = 11;
  frozenSession.scoreVersion = 9;
  const frozenReload = normalizePrototypeData(frozenInput).arrangements.find(
    (a) => a.id === "exam-grade-evidence-frozen-20261022",
  ).sessions[0];
  assert.equal(frozenReload.score, 81);
  assert.equal(frozenReload.steps[0].effectiveScore, 11);
  assert.equal(frozenReload.scoreVersion, 9);
  const pendingDemo = normalized.arrangements.find(
    (a) => a.id === "practice-grade-evidence-pending-20261022",
  ).sessions[0];
  assert.equal(pendingDemo.resultStatus, "待复核");
  assert.equal(pendingDemo.steps[0].scoreDisposition.status, "pending");
  console.log(
    "PASS 第三批已修订分、版本、原判、任务阻断及冻结成绩加载保持一致",
  );

  const { StepEvaluationExplanation, stepJudgementProcessId } =
    await server.ssrLoadModule("/src/VisualEvaluation.jsx");
  const longStep = {
    id: "Step 长文本业务样例",
    name: "双手绝缘防护及万用表检测过程完整检查".repeat(5),
    state: "active",
    executionState: "active",
    observation:
      "已进入当前步骤，工具、双手与工件接触过程需要连续观察。".repeat(20),
    completionCondition:
      "教师要求在规定工位完成安全检查和测量操作，允许合理的动作差异。".repeat(
        20,
      ),
    result: "进行中，尚未形成完整证据",
    visualRequirements: [],
  };
  const longHtml = renderToString(
    React.createElement(StepEvaluationExplanation, { step: longStep }),
  );
  assert.ok(
    longHtml.includes(longStep.observation) &&
      longHtml.includes(longStep.completionCondition) &&
      longHtml.includes(longStep.name),
    "长业务文本在完整详情中保留",
  );
  assert.ok(
    longHtml.includes(
      'id="' +
        stepJudgementProcessId(longStep) +
        '" class="step-evaluation-process"',
    ),
    "长文本详情默认折叠，定位标识稳定",
  );
  assert.ok(
    longHtml.includes('class="step-judgement-process"'),
    "判定过程使用纵向布局容器",
  );
  console.log("PASS 长步骤名、长观察及长标准的完整详情与默认折叠");
  const { StudentCameraPreview } = await server.ssrLoadModule(
    "/src/StudentCameraPreview.jsx",
  );
  for (const [arrangementId, stationId, expectedCount] of [
    ["p1", "w2", 2],
    ["e-demo-exam", "w5", 1],
    ["practice-demo-20261015", "ws-demo-20261015", 5],
  ]) {
    const session = normalized.arrangements
      .find((a) => a.id === arrangementId)
      .sessions.find((s) => s.workstationId === stationId);
    const props = {
      data: normalized,
      session,
      workstation: normalized.workstations.find((w) => w.id === stationId),
      student: normalized.students.find((s) => s.id === session.studentId),
    };
    const cameraHtml = renderToString(
      React.createElement(StudentCameraPreview, props),
    );
    if (expectedCount === 2)
      assert.ok(
        cameraHtml.includes('aria-label="选择工位摄像头"') &&
          cameraHtml.includes("细节视角") &&
          (cameraHtml.match(/<option /g) || []).length === 2,
        "学生双镜头在标题行提供下拉切换",
      );
    if (expectedCount > 1) {
      const header =
        cameraHtml.match(/<header>([\s\S]*?)<\/header>/)?.[1] || "";
      assert.ok(
        header.includes('aria-label="选择工位摄像头"'),
        "切换控件位于卡片右上角标题行",
      );
      assert.ok(
        !cameraHtml.includes('class="student-camera-switcher"') &&
          !cameraHtml.includes('role="tablist"'),
        "不再占用单独按钮行和说明行",
      );
    }
    if (expectedCount === 1)
      assert.ok(
        !cameraHtml.includes('role="tablist"') &&
          !cameraHtml.includes("<select"),
        "单镜头不添加虚构视角",
      );
    if (expectedCount === 5)
      assert.equal(
        (cameraHtml.match(/<option /g) || []).length,
        5,
        "多镜头下拉提供全部五个视角",
      );
    assert.ok(
      cameraHtml.includes("演示画面") && !cameraHtml.includes("实时得分"),
      "画面切换无评分信息，不泄露考试结果",
    );
  }
  console.log("PASS 学生单、双、五镜头预览组件及考试信息边界");
  const paths = [
    "/admin/practices/p1/students/s1",
    "/admin/exams/e1/students/s1",
    "/teacher/dashboard",
    "/teacher/evidence-tasks/task-grade-evidence-pending-20261022",
    "/teacher/evidence-tasks/task-grade-evidence-handling-20261022",
    "/teacher/evidence-tasks/task-grade-evidence-awaiting-20261022",
    "/teacher/evidence-tasks/task-grade-evidence-completed-20261022",
    "/teacher/evidence-tasks/task-grade-evidence-cancelled-20261022",
    "/teacher/evidence-tasks/task-grade-evidence-frozen-20261022",
    "/teacher/practices/practice-grade-evidence-completed-20261022/students/student-demo-20261015?sessionId=session-grade-evidence-completed-20261022",
    "/teacher/exams/exam-grade-evidence-awaiting-20261022/students/student-demo-20261015?sessionId=session-grade-evidence-awaiting-20261022",
    "/admin/exams/exam-grade-evidence-awaiting-20261022/students/student-demo-20261015?sessionId=session-grade-evidence-awaiting-20261022",
    "/admin/practices/practice-grade-evidence-completed-20261022/students/student-demo-20261015?sessionId=session-grade-evidence-completed-20261022",

    "/teacher/practices/practice-closure-manual-20261022/stations/ws-closure-manual-20261022",
    "/teacher/practices/practice-closure-teacher-20261022/stations/ws-closure-teacher-20261022",
    "/teacher/practices/practice-closure-fault-20261022/stations/ws-closure-fault-20261022",
    "/teacher/practices/practice-closure-auto-20261022/students/student-demo-20261015?sessionId=session-closure-auto-20261022",
    "/teacher/exams/exam-closure-exam-running-20261022/stations/ws-closure-exam-running-20261022",
    "/teacher/practices",
    "/teacher/exams",
    "/teacher/practices/new",
    "/teacher/exams/new",
    "/teacher/practices/practice-allocation-draft-20261022/edit",
    "/teacher/practices/practice-allocation-ready-20261022/prep",
    "/teacher/practices/practice-preparation-open-20261022/prep",
    "/teacher/exams/exam-preparation-cancelled-20261022/prep",
    "/admin/exams/exam-preparation-cancelled-20261022",
    "/teacher/practices/p4/students/s1?sessionId=session-p4-w4",
    "/teacher/practices/p1/live",
    "/teacher/practices/p1/stations/w1",
    "/teacher/exams/e-demo-exam/stations/w5",
    "/teacher/practices/practice-demo-protection-20261015/results",
    "/teacher/practices/practice-demo-protection-20261015/stations/w1",
    "/teacher/exams/exam-demo-meter-exam-20261015/results",
    "/teacher/exams/exam-demo-meter-exam-20261015/stations/w2",
    "/teacher/practices/practice-demo-bench-afternoon-20261015/prep",
    "/teacher/exams/exam-demo-bench-exam-20261015/prep",
    "/teacher/practices/practice-demo-variation-20261015/prep",
    "/teacher/practices/practice-demo-20261015/stations/ws-demo-20261015",
    "/teacher/practices/practice-demo-20261015/students/student-demo-20261015",
    "/teacher/practices/practice-demo-20261015/results",
    "/admin/ai-capability-config/sop-demo-bench-20261015",
    "/admin/ai-capability-library/annotation?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/annotation?capabilityId=cap-demo-glove-20261015",
    "/admin/ai-capability-library/videos?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/training-data?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/training?capabilityId=cap-demo-meter-20261015",
    "/admin/ai-capability-library/publishing?capabilityId=cap-demo-meter-20261015",
    "/admin/workstations/ws-demo-20261015",
    "/teacher/sop/sop-demo-bench-20261015",
    "/teacher/sop/edit/sop-demo-large-20261015",
    {
      pathname: "/teacher/sop/edit/sop-demo-large-20261015",
      state: { stage: 1 },
    },
  ];
  for (const entry of paths) {
    const html = renderToString(
      React.createElement(
        PrototypeDataProvider,
        null,
        React.createElement(
          MemoryRouter,
          { initialEntries: [entry] },
          React.createElement(RoutedApp),
        ),
      ),
    );
    assert.ok(html.length > 100);
    assert.ok(!html.includes("页面暂未找到"));
    if (
      typeof entry === "string" &&
      (entry.endsWith("/new") ||
        entry.includes("practice-allocation-") ||
        entry.includes("practice-preparation-open-20261022") ||
        entry.includes("exam-preparation-cancelled-20261022"))
    ) {
      assert.ok(
        html.includes('aria-label="学生与工位分配"'),
        "第一批页面展示同一分配表",
      );
    }
    if (
      typeof entry === "string" &&
      entry.includes("practice-allocation-draft-20261022")
    ) {
      assert.ok(
        html.includes("删除草稿") && html.includes("一人一工位"),
        "未配齐草稿可删除且显示分配约束",
      );
    }
    if (
      typeof entry === "string" &&
      entry.includes("practice-preparation-open-20261022")
    ) {
      assert.equal(
        (html.match(/>撤销准备<\/button>/g) || []).length,
        2,
        "归一化后的两个未开始工位均可撤销",
      );
      assert.ok(html.includes("取消安排"));
    }
    if (
      typeof entry === "string" &&
      entry.includes("exam-preparation-cancelled-20261022")
    ) {
      assert.ok(
        html.includes("已取消") && !html.includes("开始并进入实时监控"),
      );
      assert.equal(
        html.includes("复制为新草稿"),
        entry.startsWith("/teacher/"),
        "取消历史只允许教师复制，管理结果保持只读",
      );
    }
    if (typeof entry === "object") assert.ok(html.includes("可见操作要求"));
    if (typeof entry === "string" && entry.includes("/stations/ws-closure-")) {
      assert.ok(
        html.includes("步骤流程确认") && html.includes("学生求助办理"),
        "第二批工位提供正式办理入口",
      );
      if (entry.includes("closure-manual"))
        assert.ok(
          html.includes("接手处理") &&
            html.includes("教师回执") &&
            html.includes("学生已撤销"),
        );
      if (entry.includes("closure-teacher"))
        assert.ok(
          html.includes("确认本步流程并推进") &&
            html.includes("处理完成并发送回执"),
        );
      assert.ok(!html.includes("运行状态模拟（原型）"), "不恢复废弃模拟区");
    }
    if (
      typeof entry === "string" &&
      entry.startsWith("/teacher/evidence-tasks/")
    ) {
      assert.ok(html.includes("学生办理要求") && html.includes("负责教师"));
      if (entry.includes("-pending-")) assert.ok(html.includes("接手办理"));
      if (entry.includes("-handling-"))
        assert.ok(html.includes("保存登记并提交教师确认"));
      if (entry.includes("-awaiting-"))
        assert.ok(
          html.includes("确认办理完成并更新原记录") &&
            html.includes("查看引用记录"),
        );
      if (entry.includes("-completed-"))
        assert.ok(
          html.includes("完成结论") &&
            !html.includes("确认办理完成并更新原记录"),
        );
      if (entry.includes("-cancelled-"))
        assert.ok(
          html.includes("取消原因") && !html.includes(">接手办理</button>"),
        );
      if (entry.includes("-frozen-"))
        assert.ok(
          html.includes("成绩已冻结") &&
            !html.includes("确认办理完成并更新原记录"),
        );
    }
    if (
      typeof entry === "string" &&
      entry.includes("/admin/") &&
      entry.includes("grade-evidence")
    )
      assert.ok(
        !html.includes("查看与办理任务") &&
          !html.includes(">接手办理</button>") &&
          !html.includes("查看关联办理任务"),
      );
    if (
      typeof entry === "string" &&
      entry.includes("practice-grade-evidence-completed") &&
      entry.includes("/students/")
    )
      assert.ok(
        html.includes("统一成绩办理记录") &&
          html.includes("基线成绩") &&
          html.replace(/<!--.*?-->/g, "").includes("成绩版本 V3"),
      );
    if (entry === "/teacher/dashboard") {
      const schedule =
        html.match(/<div class="schedule-list">([\s\S]*?)<\/div>/)?.[1] || "";
      assert.equal(
        (schedule.match(/<button(?:\s|>)/g) || []).length,
        3,
        "教师工作台跨日期仍显示演示安排首屏",
      );
      assert.ok(!html.includes("今日暂无安排"));
    }

    if (typeof entry === "string" && entry.includes("/stations/")) {
      assert.ok(
        !html.includes('class="panel runtime-simulator"') &&
          !html.includes("运行状态模拟（原型）"),
        "已废弃的运行状态模拟区域不再展示",
      );
      assert.ok(
        html.includes('aria-label="查看工位相机"'),
        "所有工位详情统一相机选择器",
      );
      assert.ok(!html.includes('aria-label="视频视角"'), "不再使用旧主辅分支");
      assert.ok(
        !html.includes('class="decision-chain"') &&
          !html.includes('class="confidence-block"'),
        "侧栏没有横排判定链或固定满格状态条",
      );
      assert.ok(
        html.includes('<details id="step-judgement-process-') &&
          html.includes('class="step-evaluation-process"'),
        "纵向判定过程默认折叠",
      );
      assert.ok(
        html.includes('aria-controls="step-judgement-process-'),
        "右侧摘要可以定位并展开完整过程",
      );

      const beforeVideoLayout = html.slice(
        0,
        html.indexOf('class="student-monitor-layout"'),
      );
      assert.ok(
        !beforeVideoLayout.includes('class="enhancement-summary"') &&
          !beforeVideoLayout.includes("步骤证据视角"),
        "视频前不再插入辅助信息卡片",
      );
      assert.ok(
        html.includes('<details class="monitor-evidence-overview">'),
        "统计区概览默认折叠",
      );
      assert.ok(
        html.indexOf('class="enhancement-summary"') >
          html.indexOf('class="student-monitor-side"'),
        "覆盖概览位于右侧统计区",
      );
      assert.ok(
        html.includes('<details class="step-evaluation-evidence">'),
        "步骤证据视角在判定依据内按需展开",
      );
      const tiles =
        html.match(/<div class="step-result-grid">([\s\S]*?)<\/div>/)?.[1] ||
        "";
      assert.ok(
        tiles.includes("评价结果") &&
          tiles.includes("本步骤用时") &&
          tiles.includes("当前得分"),
      );
      assert.ok(
        !tiles.includes("enhancement-requirements") &&
          !tiles.includes("evaluation-meaning"),
        "长说明不再嵌入指标格",
      );
      const explanationIndex = html.indexOf(
        'class="panel step-evaluation-explanation"',
      );
      assert.ok(
        explanationIndex >
          html.indexOf('class="panel action-progress-panel"') &&
          explanationIndex < html.indexOf('class="student-monitor-side"'),
        "说明独立于右侧指标卡，放在动作列表下方",
      );
      const eventCardIndex = html.indexOf('class="panel monitor-event-card"');
      assert.ok(
        eventCardIndex > explanationIndex &&
          eventCardIndex < html.indexOf('class="student-monitor-side"'),
        "当前会话事件位于判定依据卡片下方的主列",
      );
      if (entry.includes("practice-demo-20261015")) {
        assert.ok(
          html.includes('<details class="step-evaluation-requirements">'),
          "可见要求默认折叠且可以展开",
        );
      }
      const parts = entry.split("/");
      const arrangement = normalized.arrangements.find(
        (a) => a.id === parts[3],
      );
      const session = arrangement.sessions.find(
        (s) => s.workstationId === parts[5],
      );
      const snapshot =
        session.evaluationSnapshot.workstationAiBaseConfigSnapshot;
      for (const camera of snapshot.cameras || []) {
        if (camera.enabled !== false)
          assert.ok(
            html.includes('value="' + camera.deviceId + '"'),
            "镜头取自会话快照",
          );
      }
    }

    if (typeof entry === "string" && entry.includes("/students/")) {
      assert.ok(
        html.includes('class="report-observation-summary"'),
        "报告统计与下方卡片使用独立间距容器",
      );
      const evidenceGrid =
        html.match(/<div class="evidence-explain">([\s\S]*?)<\/div>/)?.[1] ||
        "";
      assert.ok(
        !evidenceGrid.includes("enhancement-requirements"),
        "报告证据格也不嵌入长要求",
      );
      assert.ok(html.includes('class="panel step-evaluation-explanation"'));
    }
    console.log(
      "PASS " +
        (typeof entry === "string" ? entry : entry.pathname + " [操作步骤]"),
    );
  }
  console.log(
    paths.length + " 个页面/阶段渲染通过；此检查不执行浏览器视觉验收。",
  );
  // Isolated in-memory identity/storage only. Never read or write the user's browser.
  const previousWindow = globalThis.window;
  const values = new Map();
  const storage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, value) => values.set(key, String(value)),
    removeItem: (key) => values.delete(key),
  };
  values.set(
    "xingchen-student-session",
    JSON.stringify({
      studentId: "student-demo-20261015",
      method: "face",
      status: "passed",
      verifiedAt: "2026-10-22T02:00:00Z",
    }),
  );
  globalThis.window = { localStorage: storage, sessionStorage: storage };
  try {
    const studentPaths = [
      "/student/current",
      "/student/results/practice-grade-evidence-completed-20261022/session-grade-evidence-completed-20261022",
      "/student/results/exam-grade-evidence-awaiting-20261022/session-grade-evidence-awaiting-20261022",
      "/student/results/exam-grade-evidence-frozen-20261022/session-grade-evidence-frozen-20261022",

      "/student/session/practice-closure-fault-20261022/ws-closure-fault-20261022?sessionId=session-closure-fault-20261022",
      "/student/session/practice-closure-manual-20261022/ws-closure-manual-20261022?sessionId=session-closure-manual-20261022",
      "/student/results/practice-closure-practice-result-20261022/session-closure-practice-result-20261022",
      "/student/results/exam-closure-exam-wait-20261022/session-closure-exam-wait-20261022",
      "/student/results/exam-closure-exam-result-20261022/session-closure-exam-result-20261022",
      "/student/results/p1/session-p1-w1",
    ];
    for (const path of studentPaths) {
      const html = renderToString(
        React.createElement(
          PrototypeDataProvider,
          null,
          React.createElement(
            MemoryRouter,
            { initialEntries: [path] },
            React.createElement(RoutedApp),
          ),
        ),
      );
      assert.ok(!html.includes("页面暂未找到"));
      if (path === "/student/current")
        assert.ok(
          html.includes("最近完成") &&
            html.includes("查看本人结果") &&
            html.includes("查看提交状态") &&
            html.includes("查看异常与求助"),
        );
      if (path.includes("/student/session/"))
        assert.ok(
          html.includes("教师帮助与回执") && html.includes("步骤流程确认"),
        );
      if (path.includes("closure-fault"))
        assert.ok(
          html.includes("系统评价暂不可用") &&
            !html.includes("确认并开始训练") &&
            !html.includes("从断点恢复"),
        );
      if (path.includes("/student/results/exam-closure-exam-wait"))
        assert.ok(
          html.includes("待发布") &&
            !html.includes("有效得分") &&
            !html.includes("结果版本") &&
            !html.includes("双手绝缘手套"),
        );
      if (
        path.includes("/student/results/practice-closure") ||
        path.includes("/student/results/exam-closure-exam-result")
      )
        assert.ok(
          html.includes("有效得分") &&
            html.replace(/<!--.*?-->/g, "").includes("结果版本 V1"),
        );
      if (
        path.includes("/student/results/") &&
        path.includes("grade-evidence")
      ) {
        assert.ok(html.includes("补证与补测办理"));
        if (path.includes("exam-grade-evidence-awaiting"))
          assert.ok(
            !html.includes("有效得分") &&
              !html.includes("核验依据") &&
              !html.includes("现场结果") &&
              html.includes("待教师确认"),
          );
        if (path.includes("practice-grade-evidence-completed"))
          assert.ok(
            html.replace(/<!--.*?-->/g, "").includes("结果版本 V3") &&
              html.includes("办理结论"),
          );
      }
      if (path === "/student/results/p1/session-p1-w1")
        assert.ok(html.includes("结果暂不可查看") && !html.includes("35 分"));
      console.log("PASS " + path);
    }
    const invalidData = structuredClone(normalized);
    invalidData.evidenceTasks.push({
      id: "task-invalid-history",
      teacherId: "t1",
      studentId: "student-demo-20261015",
      arrangementId: "missing-arrangement",
      sessionId: "missing-session",
      stepId: "missing-step",
      kind: "evidence",
      status: "pending",
      revision: 1,
      studentInstruction: "历史关联失效",
      history: [],
    });
    values.set("xingchen-prototype-data-v22", JSON.stringify(invalidData));
    const invalidHtml = renderToString(
      React.createElement(
        PrototypeDataProvider,
        null,
        React.createElement(
          MemoryRouter,
          { initialEntries: ["/teacher/evidence-tasks/task-invalid-history"] },
          React.createElement(RoutedApp),
        ),
      ),
    );
    assert.ok(
      invalidHtml.includes("原会话或步骤已失效") &&
        !invalidHtml.includes(">接手办理</button>"),
    );
    console.log("PASS 失效关联任务只读历史，不导致页面抛错");
    console.log(
      `${paths.length + studentPaths.length + 1} 个页面/阶段合计通过（含10个隔离学生身份页面和1个失效历史任务），未执行浏览器视觉验收。`,
    );
  } finally {
    if (previousWindow === undefined) delete globalThis.window;
    else globalThis.window = previousWindow;
  }
} finally {
  await server.close();
  hmr.close();
  rmSync(cacheDir, { recursive: true, force: true });
}
