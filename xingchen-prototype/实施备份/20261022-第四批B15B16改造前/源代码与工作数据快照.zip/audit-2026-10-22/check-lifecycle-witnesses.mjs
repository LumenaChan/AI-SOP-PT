// Audit witnesses against the existing domain adapter; no application storage writes.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  createOpenArrangement,
  createStudentRuntimeStore,
  studentRuntimeFixture,
} from "../tests/student-e2e-fixture.mjs";
import {
  buildStudentIdentityVerification,
  createStudentIdentitySession,
  getStudentCurrentSessions,
} from "../src/studentIdentityRules.js";
import { getStudentSessionAccess } from "../src/studentPracticeRules.js";
import { examRemainingSeconds } from "../src/studentExamRules.js";

function started(type) {
  const data = studentRuntimeFixture();
  const context = createStudentRuntimeStore(data);
  const arrangement = createOpenArrangement(context.store, data, type);
  const stationId = data.workstations[0].id;
  context.store.attachStudentIdentityVerification(
    arrangement.id,
    stationId,
    buildStudentIdentityVerification(createStudentIdentitySession("student-e2e", context.clock.now())),
  );
  context.store.startWorkstationSession(arrangement.id, stationId);
  return { ...context, arrangement, stationId };
}

const practice = started("practice");
practice.store.requestTeacherHelp(practice.arrangement.id, practice.stationId, { reasonLabel: "第一次原因" });
practice.store.requestTeacherHelp(practice.arrangement.id, practice.stationId, { reasonLabel: "第二次原因" });
let session = practice.store.getData().arrangements[0].sessions[0];
const helpEvents = session.events.filter((event) => event.type === "practice_help_requested");
assert.equal(helpEvents.length, 1);
assert.equal(helpEvents[0].reasonLabel, "第一次原因");
practice.store.finishWorkstationSession(practice.arrangement.id, practice.stationId);
const completedData = practice.store.getData();
const currentAfterCompletion = getStudentCurrentSessions(completedData, "student-e2e").length;
assert.equal(currentAfterCompletion, 0);
const completedAccess = getStudentSessionAccess(completedData, "student-e2e", practice.arrangement.id, practice.stationId).allowed;
completedData.arrangements[0].sessions[0].status = "已复位";
const resetAccess = getStudentSessionAccess(completedData, "student-e2e", practice.arrangement.id, practice.stationId).allowed;
assert.equal(resetAccess, false);

const exam = started("exam");
session = exam.store.getData().arrangements[0].sessions[0];
const remainingInitially = examRemainingSeconds(session, exam.clock.value());
exam.clock.advance(60);
session = exam.store.getData().arrangements[0].sessions[0];
const after60Seconds = { remaining: examRemainingSeconds(session, exam.clock.value()), elapsed: session.elapsed, accumulator: session.runtime.evaluationClock.elapsedSeconds };
assert.equal(after60Seconds.remaining, remainingInitially - 60);
assert.equal(after60Seconds.accumulator, 0);
exam.clock.advance(300);
session = exam.store.getData().arrangements[0].sessions[0];
const withoutClientSubmission = { remaining: examRemainingSeconds(session, exam.clock.value()), status: session.status };
assert.equal(withoutClientSubmission.remaining, 0);
assert.equal(withoutClientSubmission.status, "进行中");

const assignmentData = studentRuntimeFixture();
const assignments = createStudentRuntimeStore(assignmentData);
const arrangement = assignments.store.saveArrangement({ name: "审查隔离样例", type: "practice", sopId: assignmentData.sops[0].id, scheduleStart: "2026-09-28T14:00:00", studentIds: ["student-e2e", "second", "third"], workstationIds: [assignmentData.workstations[0].id] }, true);
assignments.store.openArrangementWorkstation(arrangement.id, assignmentData.workstations[0].id, { node: true, mainCamera: true, cache: true });
const assigned = assignments.store.getData().arrangements[0];
assert.equal(assigned.sessions.length, 1);

const raw = JSON.parse(readFileSync(new URL("../src/data/currentPrototypeData.json", import.meta.url), "utf8"));
const rawSessions = raw.arrangements.flatMap((a) => a.sessions || []);
console.log(JSON.stringify({
  boundary: "isolated domain adapter witnesses; UI entry findings separately traced in source; no browser mutation",
  help: { eventCountAfterTwoRequests: helpEvents.length, savedReason: helpEvents[0].reasonLabel },
  resultAccess: { currentAfterCompletion, completedAccess, afterReset: resetAccess },
  timing: { remainingInitially, after60Seconds, withoutClientSubmission },
  assignment: { selectedStudents: assigned.studentIds.length, sessions: assigned.sessions.length, assignedStudents: assigned.sessions.map((s) => s.studentId) },
  cpd: { sessions: rawSessions.length, pendingSafety: rawSessions.flatMap((s) => s.runtime?.safetyCandidates || []).filter((c) => c.status === "pending").length },
}, null, 2));
