// Read-only audit probe: execute the dashboard's current KPI expressions verbatim.
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { teacherPrototypeSchedule } from "../src/dashboardRules.js";
import { teacherSessionEvents } from "../src/studentTeacherLinkRules.js";

const root = new URL("../", import.meta.url);
const source = readFileSync(new URL("src/App.jsx", root), "utf8");
const start = source.indexOf("  const activeArrangements =", source.indexOf("function Dashboard()"));
const end = source.indexOf("  const errorCounts =", start);
assert.ok(start > 0 && end > start);
const expressions = source.slice(start, end);
const evaluate = (data) => vm.runInNewContext(
  `(() => { ${expressions}\nreturn { averageScore, publishedRate, supportCount, scoredCount: scoredSessions.length }; })()`,
  { data, schedulePage: 0, teacherPrototypeSchedule, teacherSessionEvents },
);
const makeData = (sessions, type = "practice", teacherId = "t1") => ({
  arrangements: [{ id: "audit", type, teacherId, status: "已结束", sessions }],
});
const score = (id, studentId, value, status = "正式成绩") => ({
  id, studentId, score: value, status: "已完成", resultStatus: status, steps: [],
});
const raw = JSON.parse(readFileSync(new URL("src/data/currentPrototypeData.json", root), "utf8"));
const originalBytes = JSON.stringify(raw);
const current = evaluate(raw);
const examOnly = raw.arrangements.filter((a) => !a.archivedRecord && a.type === "exam")
  .flatMap((a) => a.sessions || [])
  .filter((s) => ["正式成绩", "已发布"].includes(s.resultStatus) && s.score !== null && s.score !== "" && Number.isFinite(Number(s.score)));
const duplicateStudent = evaluate(makeData([score("one", "same-student", 60), score("two", "same-student", 70)]));
const missingScore = evaluate(makeData([score("missing", "student", null)]));
const otherTeacherData = makeData([score("own", "student", 90)]);
otherTeacherData.arrangements.push({ id: "other", type: "practice", teacherId: "t2", status: "已结束", sessions: [score("other", "another", 10)] });
const crossTeacher = evaluate(otherTeacherData);
const pendingData = makeData([{ ...score("active", "student", 20), status: "进行中" }]);
const activeFormal = evaluate(pendingData);
const oldData = makeData([score("old", "student", 50)]);
oldData.arrangements[0].scheduleStart = "2020-01-01T09:00:00";
const oldRecord = evaluate(oldData);
assert.equal(duplicateStudent.supportCount, 2);
assert.equal(missingScore.scoredCount, 1);
assert.equal(crossTeacher.averageScore, "50.0");
assert.equal(activeFormal.scoredCount, 1);
assert.equal(oldRecord.scoredCount, 1);
assert.equal(JSON.stringify(raw), originalBytes);
console.log(JSON.stringify({
  source: fileURLToPath(new URL("src/App.jsx", root)),
  sourceLine: source.slice(0, start).split("\n").length,
  mode: "source expressions; CPD snapshot and isolated synthetic witnesses; no browser writes",
  cpd: { ...current, examReadyCount: examOnly.length, examPublishedCount: examOnly.filter((s) => s.resultStatus === "已发布").length, examOnlyRate: `${Math.round(examOnly.filter((s) => s.resultStatus === "已发布").length / examOnly.length * 100)}%` },
  witnesses: { duplicateStudent, missingScore, crossTeacher, activeFormal, oldRecord },
  unchanged: true,
}, null, 2));
