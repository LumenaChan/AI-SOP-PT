function gradeFields(session) {
  return {
    score: session.score,
    scoreEngine: session.scoreEngine,
    scoreVersion: session.scoreVersion,
    resultStatus: session.resultStatus,
    rawScore: session.rawScore,
    manualAdjustments: session.manualAdjustments,
    originalScoreRecord: session.originalScoreRecord,
    scoreRevisions: session.scoreRevisions,
    gradeAuditHistory: session.gradeAuditHistory,
    gradeRevisionSeq: session.gradeRevisionSeq,
    gradeOperationReceipts: session.gradeOperationReceipts,
    reviewHistory: session.reviewHistory,
    steps: (session.steps || []).map((s) => ({
      id: s.id,
      score: s.score,
      effectiveScore: s.effectiveScore,
      rawScore: s.rawScore,
      maxScore: s.maxScore,
      originalScoreRecord: s.originalScoreRecord,
      result: s.result,
      reviewStatus: s.reviewStatus,
      reviewedAt: s.reviewedAt,
      reviewer: s.reviewer,
      evidenceArchived: s.evidenceArchived,
      completionResult: s.completionResult,
      reviewNote: s.reviewNote,
      scoreDisposition: s.scoreDisposition,
      completionSource: s.completionSource,
      aiEvidenceState: s.aiEvidenceState,
      flowCompletion: s.flowCompletion,
    })),
  };
}
// A final write guard also protects published grades from older runtime commands.
// Metadata such as workstation reset or media retention can still change.
export function assertFrozenGradeWrite(before, next) {
  for (const arrangement of before.arrangements || [])
    for (const session of arrangement.sessions || []) {
      if (
        arrangement.status !== "已发布" &&
        session.resultStatus !== "已发布" &&
        !session.scoreFrozen
      )
        continue;
      const candidateArrangement = (next.arrangements || []).find(
        (a) => a.id === arrangement.id,
      );
      const candidate = candidateArrangement?.sessions?.find(
        (s) => s.id === session.id,
      );
      if (
        !candidate ||
        JSON.stringify(gradeFields(candidate)) !==
          JSON.stringify(gradeFields(session)) ||
        (session.scoreFrozen && !candidate.scoreFrozen) ||
        (arrangement.status === "已发布" &&
          !["已发布", "已归档"].includes(candidateArrangement.status))
      )
        throw new Error(
          "成绩已发布或冻结，普通操作不能修改原判、有效分、版本或复核记录。",
        );
    }
  return next;
}
