import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.cwd();
const imp=p=>import(pathToFileURL(root+'/src/'+p));
const {changeEvidenceTask,evidenceTaskGradeContext}=await imp('evidenceTaskRules.js');
const {scoreRevisionToken}=await imp('gradeRevisionRules.js');
const {getExamPublishGate,getPublishBlockers}=await imp('domainRules.js');
const {teacherDashboardMetrics}=await imp('teacherDashboardMetrics.js');
const raw=()=>JSON.parse(fs.readFileSync(root+'/src/data/currentPrototypeData.json'));
let data=raw(), seq=0;
const aId='practice-dashboard-empty-20261022';
const locate=()=>data.arrangements.find(a=>a.id===aId);
function act(input){const a=locate(),s=a.sessions[0]; const out=changeEvidenceTask(data,{arrangementId:a.id,sessionId:s.id,expectedVersion:s.scoreVersion,expectedRevision:scoreRevisionToken(s),actorId:'t1',at:'2026-10-23T01:00:00Z',operationId:'op'+(++seq),makeId:p=>p+'-'+(++seq),reason:'复核现场记录',studentInstruction:'请联系教师核实',kind:'evidence',...input});data=out.data;return out.result;}
console.log('NULL BEFORE',locate().sessions[0].score,locate().sessions[0].scoreVersion);
const task=act({action:'create',stepId:locate().sessions[0].steps[0].id});
console.log('NULL AFTER CREATE',locate().sessions[0].score,locate().sessions[0].scoreVersion);
act({action:'cancel',taskId:task.id,expectedTaskRevision:task.revision});
console.log('NULL AFTER CANCEL',locate().sessions[0].score,locate().sessions[0].scoreVersion,'valid',teacherDashboardMetrics(data).average.rows.some(r=>r.arrangementId===aId));
data=raw(); const source=locate().sessions[0]; source.score=100;source.steps.forEach(s=>{s.score=s.maxScore;s.effectiveScore=s.maxScore;s.reviewStatus='无需复核';s.scoreDisposition={status:'normal'};s.redlineConfirmed=false;s.state='pass';});source.resultStatus='正式成绩';
const t1=act({action:'create',stepId:source.steps[0].id});const t2=act({action:'create',stepId:source.steps[1].id});
act({action:'cancel',taskId:t1.id,expectedTaskRevision:t1.revision});act({action:'cancel',taskId:t2.id,expectedTaskRevision:t2.revision});
console.log('CANCEL ALL',JSON.stringify({status:locate().sessions[0].resultStatus,steps:locate().sessions[0].steps.map(s=>({review:s.reviewStatus,disposition:s.scoreDisposition.status})),tasks:data.evidenceTasks.filter(t=>t.arrangementId===aId).map(t=>t.status)}));
for(const score of [null, '', -1, 101]) {const d=raw(),a=d.arrangements.find(a=>a.id==='exam-dashboard-unpublished-20261022'),s=a.sessions[0];s.score=score;console.log('PUBLISH',JSON.stringify({score,gate:getExamPublishGate(a.sessions),writeBlockers:getPublishBlockers(a.sessions).length,included:teacherDashboardMetrics(d).publishing.ready.some(r=>r.sessionId===s.id)}));}
