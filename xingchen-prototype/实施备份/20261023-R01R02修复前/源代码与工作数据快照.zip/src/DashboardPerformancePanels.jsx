import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { usePrototypeData } from "./prototypeData.jsx";
import { teacherDashboardMetrics } from "./teacherDashboardMetrics.js";
import { openSupportTasks, SUPPORT_TASK_STATUSES } from "./supportTaskRules.js";
import { SupportTaskCreate } from "./SupportTaskPanels.jsx";

const keyOf = (row) => `${row.arrangementId}/${row.sessionId}`;
function Pager({ page, count, onChange }) {
  return (
    <span className="dashboard-detail-pager">
      <button disabled={!page} onClick={() => onChange(page - 1)}>
        上一页
      </button>
      <span>
        {page + 1} / {count}
      </span>
      <button disabled={page >= count - 1} onClick={() => onChange(page + 1)}>
        下一页
      </button>
    </span>
  );
}
function ResultRows({
  rows = [],
  empty = "当前范围没有符合条件的结果。",
  excluded = false,
  createSupport = false,
  filters,
  publication = false,
}) {
  const nav = useNavigate(),
    [page, setPage] = useState(0);
  const count = Math.max(1, Math.ceil(rows.length / 8)),
    safe = Math.min(page, count - 1);
  return (
    <>
      <p className="hint">
        共 {rows.length} 条
        {excluded ? "来源记录" : createSupport ? "学生依据" : "完成记录"}
        {!excluded && !createSupport && "，每次完成分别计入样本"}。
      </p>
      {!rows.length ? (
        <p className="hint">{empty}</p>
      ) : (
        <div className="dashboard-result-list">
          {rows.slice(safe * 8, (safe + 1) * 8).map((r) => (
            <article key={keyOf(r)}>
              <div>
                <strong>
                  {r.student?.name || r.studentName || r.studentId} ·{" "}
                  {r.arrangement?.name || r.arrangementId}
                </strong>
                <p>
                  {r.type === "exam" ? "考试" : "练习"} · {r.sopName || r.sopId}{" "}
                  · {r.sopVersion} · {r.resultAt || "未记录结果时间"}
                </p>
                <p>
                  {r.valid
                    ? `${r.score}/${r.maxScore} 分（百分制 ${Number(r.normalizedScore).toFixed(1)}） · V${r.scoreVersion}`
                    : (r.exclusionLabels || r.exclusionReasons || []).join(
                        "；",
                      )}
                </p>
                {publication && r.publishingExclusionLabels?.length > 0 && (
                  <p>{r.publishingExclusionLabels.join("；")}</p>
                )}
                {r.stepId && (
                  <p>
                    {r.stepName}：{r.stepScore}/{r.stepMaxScore} 分 · 扣分{" "}
                    {r.deduction} 分 ·{" "}
                    {(r.sources || []).map((s) => s.reason).join("；")}
                  </p>
                )}
                <p>
                  {(r.sourceLabels || []).join(" · ") ||
                    r.source ||
                    "结果依据见源报告"}
                </p>
                {r.reason && <p>{r.reason}</p>}
                {createSupport && (
                  <p>负责教师：{r.teacherName || "当前教师"}</p>
                )}
              </div>
              <div className="dashboard-row-actions">
                <button onClick={() => nav(r.reportPath)}>查看源结果</button>
                {publication && r.arrangement?.status === "待发布" && (
                  <button
                    onClick={() =>
                      nav(`/teacher/exams/${r.arrangementId}/results`)
                    }
                  >
                    进入考试成绩处理
                  </button>
                )}
                {createSupport && (
                  <SupportTaskCreate row={r} filters={filters} />
                )}
              </div>
            </article>
          ))}
        </div>
      )}
      {count > 1 && <Pager page={safe} count={count} onChange={setPage} />}
    </>
  );
}
export function DashboardPerformanceSection() {
  const { data } = usePrototypeData(),
    nav = useNavigate();
  const [filters, setFilters] = useState({
    teacherId: "t1",
    classId: "",
    courseId: "",
    sopId: "",
    sopVersion: "",
    type: "",
    from: "",
    to: "",
  });
  const [searchParams, setSearchParams] = useSearchParams();
  const detail = ["average", "publishing", "support", "errors"].includes(
    searchParams.get("metric"),
  )
    ? searchParams.get("metric")
    : "";
  const setDetail = (value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set("metric", value);
    else next.delete("metric");
    setSearchParams(next, { replace: true });
  };
  const [publishTab, setPublishTab] = useState("published"),
    [taskHistory, setTaskHistory] = useState(false),
    [errorPage, setErrorPage] = useState(0);
  const metrics = teacherDashboardMetrics(data, filters),
    options = metrics.scope.options;
  const keys = new Set(metrics.rows.map(keyOf));
  const tasks = (data.supportTasks || []).filter(
    (t) => t.teacherId === "t1" && keys.has(keyOf(t)),
  );
  const openIds = new Set(openSupportTasks(data, "t1").map((t) => t.id));
  const openTasks = tasks.filter((t) => openIds.has(t.id));
  const supportCount = new Set(openTasks.map((t) => t.studentId)).size;
  const [selectedError, setSelectedError] = useState("");
  const errCount = Math.max(1, Math.ceil(metrics.errors.length / 3)),
    safeError = Math.min(errorPage, errCount - 1);
  const activeError = metrics.errors.find(
    (e) =>
      (e.key || `${e.sopId}/${e.sopVersion}/${e.stepId}`) === selectedError,
  );
  const change = (field, value) => {
    setFilters({
      ...filters,
      [field]: value,
      ...(field === "sopId" ? { sopVersion: "" } : {}),
    });
    setErrorPage(0);
  };
  const scopeLabel = [
    filters.classId &&
      options.classes.find((o) => o.id === filters.classId)?.name,
    filters.courseId &&
      options.courses.find((o) => o.id === filters.courseId)?.name,
    filters.sopId && options.sops.find((o) => o.id === filters.sopId)?.name,
    filters.sopVersion,
    filters.type === "exam"
      ? "考试"
      : filters.type === "practice"
        ? "练习"
        : "练习与考试",
    filters.from || filters.to
      ? `${filters.from || "不限开始"} 至 ${filters.to || "不限结束"}`
      : "全部演示记录",
  ]
    .filter(Boolean)
    .join(" · ");
  const fieldSelect = (name, label, items) => (
    <label>
      {label}
      <select
        value={filters[name]}
        onChange={(e) => change(name, e.target.value)}
      >
        <option value="">全部{label}</option>
        {[...new Map(items.map((o) => [o.id, o])).values()].map((o) => (
          <option key={o.id} value={o.id}>
            {o.name}
          </option>
        ))}
      </select>
    </label>
  );
  return (
    <section className="dashboard-performance-section">
      <div className="panel dashboard-scope-panel">
        <div className="panel-title">
          <h2>{metrics.scope.label}</h2>
          <span>当前教师：王老师</span>
        </div>
        <p className="hint">
          统计范围：{scopeLabel}。保留各记录原日期，默认不按当前日期筛选。
        </p>
        <details>
          <summary>筛选统计范围</summary>
          <div className="dashboard-filter-grid">
            {fieldSelect("classId", "班级", options.classes)}
            {fieldSelect("courseId", "课程", options.courses)}
            {fieldSelect("sopId", "SOP", options.sops)}
            {fieldSelect(
              "sopVersion",
              "版本",
              options.sopVersions.filter(
                (o) => !filters.sopId || o.sopId === filters.sopId,
              ),
            )}
            {fieldSelect("type", "结果类型", [
              { id: "practice", name: "练习" },
              { id: "exam", name: "考试" },
            ])}
            <label>
              结果开始日期
              <input
                type="date"
                value={filters.from}
                onChange={(e) => change("from", e.target.value)}
              />
            </label>
            <label>
              结果结束日期
              <input
                type="date"
                value={filters.to}
                onChange={(e) => change("to", e.target.value)}
              />
            </label>
            <button
              className="button button--default"
              onClick={() =>
                setFilters({
                  teacherId: "t1",
                  classId: "",
                  courseId: "",
                  sopId: "",
                  sopVersion: "",
                  type: "",
                  from: "",
                  to: "",
                })
              }
            >
              重置为全部演示记录
            </button>
          </div>
        </details>
      </div>
      <div className="dashboard-grid">
        <section className="panel">
          <h2>学生表现</h2>
          <div className="dashboard-performance-metrics">
            <button
              onClick={() => setDetail(detail === "average" ? "" : "average")}
            >
              <strong>
                {metrics.average.value == null
                  ? "—"
                  : Number(metrics.average.value).toFixed(1)}
              </strong>
              <span>平均得分（百分制）</span>
              <small>{metrics.average.count} 人次有效正式结果 · 查看明细</small>
            </button>
            <button
              onClick={() =>
                setDetail(detail === "publishing" ? "" : "publishing")
              }
            >
              <strong>
                {metrics.publishing.denominator
                  ? `${Math.round(metrics.publishing.value)}%`
                  : "—"}
              </strong>
              <span>考试成绩发布率</span>
              <small>
                {metrics.publishing.numerator}/{metrics.publishing.denominator}{" "}
                份 · 待复核 {metrics.publishing.pendingCount} 份
              </small>
              {!metrics.publishing.denominator && <small>暂无可发布结果</small>}
            </button>
            <button
              onClick={() => setDetail(detail === "support" ? "" : "support")}
            >
              <strong>{supportCount}</strong>
              <span>待辅导学生</span>
              <small>{openTasks.length} 项未结任务 · 按学生去重</small>
            </button>
          </div>
          <p className="hint">
            平均分按完成记录人次统计；缺证保分仍为政策有效分，不代表AI识别效果或技能掌握率。
          </p>
        </section>
        <section className="panel teacher-error-card">
          <div className="panel-title">
            <h2>高频错误</h2>
            <Pager page={safeError} count={errCount} onChange={setErrorPage} />
          </div>
          <div className="rank-list dashboard-error-list">
            {metrics.errors
              .slice(safeError * 3, (safeError + 1) * 3)
              .map((e, i) => (
                <button
                  key={e.key || `${e.sopId}/${e.sopVersion}/${e.stepId}`}
                  onClick={() => {
                    setSelectedError(
                      e.key || `${e.sopId}/${e.sopVersion}/${e.stepId}`,
                    );
                    setDetail("errors");
                  }}
                >
                  <b>{safeError * 3 + i + 1}</b>
                  <span>
                    {e.stepName}
                    <small>
                      {e.sopName || e.sopId} · {e.sopVersion}
                    </small>
                  </span>
                  <em>{e.count} 条 · 查看</em>
                </button>
              ))}
            {!metrics.errors.length && (
              <p className="hint">当前范围暂无已确认的有效扣分记录。</p>
            )}
          </div>
          <p className="hint">
            按SOP版本与步骤分别统计，待确认及仅缺证保分不算错误。
          </p>
        </section>
      </div>
      {detail && (
        <section className="panel dashboard-metric-details">
          <div className="panel-title">
            <h2>
              {
                {
                  average: "平均得分明细",
                  publishing: "考试成绩发布明细",
                  support: "学生辅导与低分依据",
                  errors: "错误来源明细",
                }[detail]
              }
            </h2>
            <button onClick={() => setDetail("")}>收起明细</button>
          </div>
          <p className="hint">当前范围：{scopeLabel}</p>
          {detail === "average" && (
            <>
              <ResultRows rows={metrics.average.rows} />
              <details>
                <summary>
                  排除的记录 · {metrics.average.excludedCount} 条
                </summary>
                <ResultRows rows={metrics.average.excluded} excluded />
              </details>
            </>
          )}
          {detail === "publishing" && (
            <>
              <div className="dashboard-detail-tabs">
                {[
                  ["published", "已发布"],
                  ["ready", "待发布"],
                  ["pending", "待复核"],
                  ["excluded", "不计入发布率"],
                ].map(([id, label]) => (
                  <button
                    className={publishTab === id ? "active" : ""}
                    key={id}
                    onClick={() => setPublishTab(id)}
                  >
                    {label}（{metrics.publishing[id].length}）
                  </button>
                ))}
              </div>
              <p className="hint">
                发布率分母 = 已发布有效考试结果 +
                已完成必要复核的待发布正式考试结果；待复核单列。
              </p>
              <ResultRows
                publication
                rows={metrics.publishing[publishTab]}
                excluded={publishTab === "pending" || publishTab === "excluded"}
              />
            </>
          )}
          {detail === "support" && (
            <>
              <div className="panel-title">
                <h3>{taskHistory ? "辅导任务历史" : "未结辅导任务"}</h3>
                <button onClick={() => setTaskHistory(!taskHistory)}>
                  {taskHistory ? "只看未结" : "查看全部任务及历史"}
                </button>
              </div>
              <div className="dashboard-result-list">
                {(taskHistory ? tasks : openTasks).map((t) => (
                  <article key={t.id}>
                    <div>
                      <strong>
                        {t.studentName || t.studentId} ·{" "}
                        {SUPPORT_TASK_STATUSES[t.status]}
                      </strong>
                      <p>{t.studentInstruction}</p>
                      <p>
                        发起时 {t.sourceScore}/{t.sourceMaxScore} 分 · V
                        {t.sourceScoreVersion} · {t.teacherName || "王老师"}
                      </p>
                    </div>
                    <button
                      onClick={() => nav(`/teacher/support-tasks/${t.id}`)}
                    >
                      查看并办理
                    </button>
                  </article>
                ))}
                {!(taskHistory ? tasks : openTasks).length && (
                  <p className="hint">
                    当前范围没有{taskHistory ? "辅导记录" : "未结辅导任务"}。
                  </p>
                )}
              </div>
              <h3>
                最近有效结果低于80分（百分制）的学生 ·{" "}
                {metrics.lowStudents.length} 人
              </h3>
              <p className="hint">
                每名学生取当前范围最近一次有效正式结果。同一学生多次低分只列一人；完成辅导不会改变历史成绩。
              </p>
              <ResultRows
                rows={metrics.lowStudents}
                filters={filters}
                createSupport
              />
            </>
          )}
          {detail === "errors" &&
            (activeError ? (
              <>
                <h3>
                  {activeError.stepName} · {activeError.sopVersion}
                </h3>
                <ResultRows rows={activeError.rows} />
              </>
            ) : (
              <p className="hint">
                该错误已不在当前范围，或成绩已修订，请重新选择。
              </p>
            ))}
        </section>
      )}
    </section>
  );
}
